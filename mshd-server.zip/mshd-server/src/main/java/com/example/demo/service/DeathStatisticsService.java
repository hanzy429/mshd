package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.pojo.Deathstatistics;
import com.example.demo.dao.DeathStatisticsDao;

import java.util.List;

@Service
public class DeathStatisticsService {
    @Autowired
    DeathStatisticsDao deathStatisticsDao;
    public List<Deathstatistics>  getById(String id){
        return deathStatisticsDao.findByDisasterInfoDId(id);
    }
}
