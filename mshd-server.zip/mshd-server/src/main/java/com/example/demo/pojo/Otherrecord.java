package com.example.demo.pojo;


public class Otherrecord {

  private String id;
  private String location;
  private String date;
  private String type;
  private String status;
  private String note;
  private String picture;
  private String reporting_Unit;
  private String disasterInfoDId;


  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }


  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }


  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }


  public String getPicture() {
    return picture;
  }

  public void setPicture(String picture) {
    this.picture = picture;
  }


  public String getReporting_Unit() {
    return reporting_Unit;
  }

  public void setReporting_Unit(String reporting_Unit) {
    this.reporting_Unit = reporting_Unit;
  }


  public String getDisasterInfoDId() {
    return disasterInfoDId;
  }

  public void setDisasterInfoDId(String disasterInfoDId) {
    this.disasterInfoDId = disasterInfoDId;
  }

}
