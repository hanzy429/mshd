package com.example.demo.pojo;


public class Missingstatistics {

  private String id;
  private String location;
  private String date;
  private long number;
  private String reporting_Unit;
  private String disasterInfoDId;


  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }


  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }


  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }


  public long getNumber() {
    return number;
  }

  public void setNumber(long number) {
    this.number = number;
  }


  public String getReporting_Unit() {
    return reporting_Unit;
  }

  public void setReporting_Unit(String reporting_Unit) {
    this.reporting_Unit = reporting_Unit;
  }


  public String getDisasterInfoDId() {
    return disasterInfoDId;
  }

  public void setDisasterInfoDId(String disasterInfoDId) {
    this.disasterInfoDId = disasterInfoDId;
  }

}
