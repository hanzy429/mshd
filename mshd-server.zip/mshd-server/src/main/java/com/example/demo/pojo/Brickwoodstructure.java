package com.example.demo.pojo;


public class Brickwoodstructure {

  private String id;
  private String date;
  private String location;
  private String basically_Intact_Square;
  private String damaged_Square;
  private String destroyed_Square;
  private String note;
  private String reporting_Unit;
  private String disasterInfoDId;


  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }


  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }


  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }


  public String getBasically_Intact_Square() {
    return basically_Intact_Square;
  }

  public void setBasically_Intact_Square(String basically_Intact_Square) {
    this.basically_Intact_Square = basically_Intact_Square;
  }


  public String getDamaged_Square() {
    return damaged_Square;
  }

  public void setDamaged_Square(String damaged_Square) {
    this.damaged_Square = damaged_Square;
  }


  public String getDestroyed_Square() {
    return destroyed_Square;
  }

  public void setDestroyed_Square(String destroyed_Square) {
    this.destroyed_Square = destroyed_Square;
  }


  public String getNote() {
    return note;
  }

  public void setNote(String note) {
    this.note = note;
  }


  public String getReporting_Unit() {
    return reporting_Unit;
  }

  public void setReporting_Unit(String reporting_Unit) {
    this.reporting_Unit = reporting_Unit;
  }


  public String getDisasterInfoDId() {
    return disasterInfoDId;
  }

  public void setDisasterInfoDId(String disasterInfoDId) {
    this.disasterInfoDId = disasterInfoDId;
  }

}
