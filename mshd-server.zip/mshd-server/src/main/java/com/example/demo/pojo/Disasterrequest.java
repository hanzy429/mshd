package com.example.demo.pojo;


public class Disasterrequest {

  private String id;
  private String date;
  private String disasterType;
  private String status;
  private String oUrl;
  private String requestunit;
  private String disasterInfoDId;


  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }


  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }


  public String getDisasterType() {
    return disasterType;
  }

  public void setDisasterType(String disasterType) {
    this.disasterType = disasterType;
  }


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  public String getOUrl() {
    return oUrl;
  }

  public void setOUrl(String oUrl) {
    this.oUrl = oUrl;
  }


  public String getRequestunit() {
    return requestunit;
  }

  public void setRequestunit(String requestunit) {
    this.requestunit = requestunit;
  }


  public String getDisasterInfoDId() {
    return disasterInfoDId;
  }

  public void setDisasterInfoDId(String disasterInfoDId) {
    this.disasterInfoDId = disasterInfoDId;
  }

}
